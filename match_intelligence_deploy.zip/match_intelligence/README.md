# Match Intelligence — ilk çalışan sürüm

Türkçe, mobil uyumlu futbol analiz dashboard'u. FastAPI backend + SQLite + vanilla JS frontend.

## Kurulum (Windows)
1. Python 3.10+ kur.
2. ZIP'i klasöre çıkar.
3. `.env.example` dosyasını `.env` olarak kopyala.
4. Ücretsiz API-Football hesabından API key al ve `.env` içindeki `API_FOOTBALL_KEY=` satırına ekle.
5. `run_windows.bat` dosyasını çalıştır.
6. Tarayıcıda `http://127.0.0.1:8000` adresini aç.
7. Tarihi seçip **Bülteni Tara** butonuna bas.

## macOS / Linux
```bash
cp .env.example .env
# .env dosyasına API_FOOTBALL_KEY ekle
chmod +x run_linux_mac.sh
./run_linux_mac.sh
```

## İlk filtre — mevcut uygulama kuralı
- Düşük gol profili: son 5 maçın en az 4'ü 2.5 ALT **veya** en az 3'ü 2.5 ALT ve en az 1'i tam 3 gol.
- Rakip yüksek gol profili: son 5 maçta en az bir maçta toplam 6 veya daha fazla gol.
- Her iki yön de kontrol edilir.
- Beş maçlık geçmişi eksik olan takım eşleşmeye alınmaz.

ÖNEMLİ: Kullanıcının örneğindeki “3 adet 2.5 alt + 1 tane 3 gollü maç” koşulu, 5 maçlık pencerede kalan bir maçın başka bir sonuç olabileceği varsayımıyla uygulanır. Tam 5 maçlık pencerede 3 ALT + 1 tam 3 gol, beşinci maç serbesttir.

## API limitleri ve kapsam
- Bu sürüm API-Football `/fixtures`, `/fixtures?id=`, `/fixtures?team=&last=5` ve `/odds` uç noktalarını kullanır.
- Ücretsiz API planının günlük istek kotası ve kapsadığı lig/istatistik/odds kapsamı sağlayıcı tarafından belirlenir ve değişebilir.
- “All leagues” seçimi, sağlayıcının ilgili gün için API'de döndürdüğü fikstürlerin tamamı anlamına gelir; dünyadaki her amatör/profesyonel lig için garanti değildir.
- Analiz endpoint'i her fikstür için detay ve iki takımın son beş maçını sorguladığından ücretsiz API kotasını hızlı tüketebilir. İlk testte tek gün ve sınırlı sayıda maçla dene.
- Oran endpoint'i planında erişime açık değilse 503 dönebilir. API key olmadan gerçek veri taraması yapılamaz.

## Otomatik tarama
İlk sürümde tarama, dashboard'daki butonla tetiklenir. Zamanlanmış tarama için sunucunun sürekli açık kalması gerekir. Sonraki sürümde sağlayıcı limitlerine göre kuyruk, cache, zamanlayıcı ve rate-limit yönetimi eklenmelidir.

## Güvenlik
- API anahtarlarını frontend dosyalarına koyma.
- `.env` dosyasını Git'e yükleme.
- Bu geliştirme sürümünü internete açık sunucuya koymadan önce kimlik doğrulama, HTTPS, CORS kısıtlaması ve rate limiting ekle.

## Sınırlamalar / dürüstlük
- “Kupon merkezi” ilk arayüz ve arşiv taslağıdır; henüz otomatik olasılık modeli veya bahis şirketi oranlarından otomatik seçim yapmaz.
- Kaydedilen ilk filtre eşleşmesi için yapay olasılık veya adil oran üretilmez; arşiv kaydı, bahis tahmini değil filtre eşleşmesi olarak işaretlenir. Gerçek model olasılığı geliştirilmeden EV/ROI iddiası yapılmamalıdır.
- Canlı maç ekranı ve canlı tahmin modeli bir sonraki geliştirme aşamasıdır; şu an API canlı skor/istatistik entegrasyonu tamamlanmış değildir.
- Bahis kaybı riski yüksektir. Hiçbir analiz kazanç garantisi vermez; sistemi karar destek ve geçmiş performans ölçümü için kullan.
