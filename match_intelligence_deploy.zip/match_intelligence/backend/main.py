import os, json, sqlite3, asyncio
from datetime import date, datetime, timedelta, timezone
from typing import Optional
import httpx
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

DB_PATH = os.getenv("DB_PATH", "match_intelligence.db")
API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY", "")
API_FOOTBALL_HOST = "https://v3.football.api-sports.io"
FOOTBALL_DATA_TOKEN = os.getenv("FOOTBALL_DATA_TOKEN", "")
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "")
SCAN_INTERVAL_MINUTES = int(os.getenv("SCAN_INTERVAL_MINUTES", "180"))

app = FastAPI(title="Match Intelligence", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS fixtures(
          id TEXT PRIMARY KEY, date TEXT, league TEXT, country TEXT, home TEXT, away TEXT,
          status TEXT, home_score INTEGER, away_score INTEGER, source TEXT, raw TEXT
        );
        CREATE TABLE IF NOT EXISTS team_form(
          fixture_id TEXT, team TEXT, is_home INTEGER, goals_for INTEGER, goals_against INTEGER,
          match_date TEXT, PRIMARY KEY(fixture_id, team)
        );
        CREATE TABLE IF NOT EXISTS odds(
          fixture_id TEXT, bookmaker TEXT, market TEXT, selection TEXT, price REAL, captured_at TEXT
        );
        CREATE TABLE IF NOT EXISTS predictions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, fixture_id TEXT, market TEXT, selection TEXT,
          probability REAL, fair_odds REAL, offered_odds REAL, score REAL, reason TEXT,
          created_at TEXT, outcome TEXT
        );
        CREATE TABLE IF NOT EXISTS scan_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT, finished_at TEXT,
          source TEXT, fixtures_count INTEGER, status TEXT, message TEXT
        );
        """)
init_db()

async def api_football(path, params=None):
    if not API_FOOTBALL_KEY:
        raise RuntimeError("API_FOOTBALL_KEY tanımlı değil.")
    headers = {"x-apisports-key": API_FOOTBALL_KEY}
    async with httpx.AsyncClient(timeout=25) as client:
        r = await client.get(API_FOOTBALL_HOST + path, params=params or {}, headers=headers)
        r.raise_for_status()
        payload = r.json()
        if payload.get("errors"):
            raise RuntimeError(str(payload["errors"]))
        return payload.get("response", [])

async def football_data(path):
    if not FOOTBALL_DATA_TOKEN:
        raise RuntimeError("FOOTBALL_DATA_TOKEN tanımlı değil.")
    async with httpx.AsyncClient(timeout=25) as client:
        r = await client.get("https://api.football-data.org/v4/" + path,
                             headers={"X-Auth-Token": FOOTBALL_DATA_TOKEN})
        r.raise_for_status()
        return r.json()

def upsert_fixture(f):
    with db() as c:
        c.execute("""INSERT OR REPLACE INTO fixtures
        (id,date,league,country,home,away,status,home_score,away_score,source,raw)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (str(f["id"]), f.get("date"), f.get("league",""), f.get("country",""),
         f.get("home",""), f.get("away",""), f.get("status","NS"),
         f.get("home_score"), f.get("away_score"), f.get("source",""),
         json.dumps(f, ensure_ascii=False)))

def normalize_api_fixture(x):
    fixture=x.get("fixture",{}); league=x.get("league",{}); teams=x.get("teams",{}); goals=x.get("goals",{})
    return {"id":fixture.get("id"),"date":fixture.get("date"),"league":league.get("name",""),
            "country":league.get("country",""),"home":teams.get("home",{}).get("name",""),
            "away":teams.get("away",{}).get("name",""),"status":fixture.get("status",{}).get("short","NS"),
            "home_score":goals.get("home"),"away_score":goals.get("away"),"source":"api-football"}

async def scan_fixtures(day: str):
    started=datetime.now(timezone.utc).isoformat()
    source="API-Football"
    try:
        rows=await api_football("/fixtures", {"date":day})
        normalized=[normalize_api_fixture(x) for x in rows if x.get("fixture",{}).get("id")]
        for f in normalized: upsert_fixture(f)
        status="ok"; msg="Fikstür taraması tamamlandı."
    except Exception as e:
        normalized=[]; status="error"; msg=str(e)
    with db() as c:
        c.execute("INSERT INTO scan_log(started_at,finished_at,source,fixtures_count,status,message) VALUES(?,?,?,?,?,?)",
                  (started,datetime.now(timezone.utc).isoformat(),source,len(normalized),status,msg))
    return {"count":len(normalized),"status":status,"message":msg}

async def get_last_five(team_id: int, before: str):
    try:
        rows=await api_football("/fixtures", {"team":team_id,"last":5,"to":before[:10],"status":"FT"})
        out=[]
        for x in rows:
            fx=x.get("fixture",{}); teams=x.get("teams",{}); goals=x.get("goals",{})
            is_home=teams.get("home",{}).get("id")==team_id
            gf=goals.get("home") if is_home else goals.get("away")
            ga=goals.get("away") if is_home else goals.get("home")
            if gf is not None and ga is not None:
                out.append({"date":fx.get("date"),"gf":gf,"ga":ga,"total":gf+ga})
        return out[:5]
    except Exception:
        return []

def evaluate_profile(home_form, away_form):
    # Kullanıcının tarif ettiği ilk filtre:
    # Takım A: son 5 maçının 4'ü 2.5 ALT VEYA 3 ALT + 1 adet tam 3 gollü maç.
    # Rakip: son 5 maçında en az bir adet toplam 6+ gollü (mavi +6) maç.
    def low_profile(form):
        if len(form) < 5: return False, "Son 5 maç verisi eksik"
        under=sum(1 for m in form if m["total"] <= 2)
        exactly_three=sum(1 for m in form if m["total"] == 3)
        # İlk örnekte belirtilen 4 ALT veya 3 ALT + 1 adet 3 gollü kombinasyon.
        ok = under >= 4 or (under >= 3 and exactly_three >= 1)
        return ok, f"{under}/5 maç 2.5 ALT, {exactly_three}/5 maç tam 3 gol"
    def blue_profile(form):
        if len(form) < 5: return False, "Son 5 maç verisi eksik"
        count=sum(1 for m in form if m["total"] >= 6)
        return count >= 1, f"{count}/5 maçta toplam 6+ gol"
    a_ok,a_note=low_profile(home_form); b_ok,b_note=blue_profile(away_form)
    b_low,b_low_note=low_profile(away_form); a_blue,a_blue_note=blue_profile(home_form)
    directions=[]
    if a_ok and b_ok: directions.append(("home_low_away_blue",a_note+"; rakip "+b_note))
    if b_low and a_blue: directions.append(("away_low_home_blue",b_low_note+"; rakip "+a_blue_note))
    return {"matched":bool(directions),"directions":directions,
            "home_low":a_ok,"away_blue":b_ok,"away_low":b_low,"home_blue":a_blue,
            "home_note":a_note,"away_note":b_note}

@app.get("/api/health")
def health():
    return {"ok":True,"app":"Match Intelligence","api_football_configured":bool(API_FOOTBALL_KEY),
            "football_data_configured":bool(FOOTBALL_DATA_TOKEN),"odds_configured":bool(ODDS_API_KEY)}

@app.post("/api/scan")
async def scan(day: str = Query(default_factory=lambda: date.today().isoformat())):
    return await scan_fixtures(day)

@app.get("/api/fixtures")
def fixtures(day: Optional[str]=None, limit: int=250):
    q="SELECT * FROM fixtures"; args=[]
    if day: q+=" WHERE date LIKE ?"; args.append(day+"%")
    q+=" ORDER BY date LIMIT ?"; args.append(limit)
    with db() as c: rows=c.execute(q,args).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/analysis")
async def analysis(day: Optional[str]=None):
    q="SELECT * FROM fixtures"; args=[]
    if day: q+=" WHERE date LIKE ?"; args.append(day+"%")
    q+=" ORDER BY date"
    with db() as c: rows=[dict(r) for r in c.execute(q,args).fetchall()]
    # Team IDs and form are in raw API payload. Query each candidate team.
    results=[]
    for f in rows:
        raw=json.loads(f["raw"] or "{}")
        # Fixtures stored in normalized form; raw team IDs are fetched from API when needed.
        try:
            detail=await api_football("/fixtures",{"id":f["id"]})
            if not detail: continue
            teams=detail[0].get("teams",{})
            hid=teams.get("home",{}).get("id"); aid=teams.get("away",{}).get("id")
            if not hid or not aid: continue
            hf=await get_last_five(hid,f["date"]); af=await get_last_five(aid,f["date"])
            profile=evaluate_profile(hf,af)
            if profile["matched"]:
                results.append({**f,"home_form":hf,"away_form":af,"profile":profile,
                                "score":min(99,70+10*len(profile["directions"]))})
        except Exception:
            continue
    return results

@app.get("/api/odds")
async def odds(fixture_id: str):
    try:
        rows=await api_football("/odds",{"fixture":fixture_id})
        return rows
    except Exception as e:
        raise HTTPException(503, str(e))

class PredictionIn(BaseModel):
    fixture_id:str; market:str; selection:str
    probability:Optional[float]=None; offered_odds:Optional[float]=None
    score:float=0; reason:str=""

@app.post("/api/predictions")
def save_prediction(p:PredictionIn):
    if p.probability is not None and not 0 < p.probability < 1: raise HTTPException(400,"Olasılık 0 ile 1 arasında olmalı.")
    fair=(1/p.probability) if p.probability is not None else None
    with db() as c:
        cur=c.execute("""INSERT INTO predictions(fixture_id,market,selection,probability,fair_odds,offered_odds,score,reason,created_at)
        VALUES(?,?,?,?,?,?,?,?,?)""",(p.fixture_id,p.market,p.selection,p.probability,fair,p.offered_odds,p.score,p.reason,datetime.now(timezone.utc).isoformat()))
        return {"id":cur.lastrowid,"fair_odds":round(fair,2)}


@app.post("/api/candidates/{fixture_id}/archive")
def archive_candidate(fixture_id: str, selection: str, reason: str = ""):
    with db() as c:
        cur=c.execute("""INSERT INTO predictions(fixture_id,market,selection,probability,fair_odds,score,reason,created_at)
        VALUES(?,?,?,?,?,?,?,?)""",(fixture_id,"Filtre eşleşmesi",selection,None,None,70,reason,datetime.now(timezone.utc).isoformat()))
        return {"id":cur.lastrowid,"archived":True}
\n@app.get("/api/predictions")
def predictions():
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT 300")]

@app.post("/api/predictions/{pid}/settle")
def settle(pid:int, outcome:str=Query(..., pattern="^(won|lost|void)$")):
    with db() as c:
        c.execute("UPDATE predictions SET outcome=? WHERE id=?",(outcome,pid))
    return {"ok":True}

@app.get("/api/stats")
def stats():
    with db() as c:
        total=c.execute("SELECT COUNT(*) n FROM predictions WHERE outcome IN ('won','lost')").fetchone()["n"]
        won=c.execute("SELECT COUNT(*) n FROM predictions WHERE outcome='won'").fetchone()["n"]
        return {"settled":total,"won":won,"lost":total-won,"hit_rate":round(won/total*100,1) if total else None}

@app.get("/api/logs")
def logs():
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM scan_log ORDER BY id DESC LIMIT 30")]

app.mount("/static",StaticFiles(directory="frontend"),name="static")
@app.get("/")
def index(): return FileResponse("frontend/index.html")
