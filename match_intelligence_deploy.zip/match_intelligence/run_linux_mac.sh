#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
set -a; [ -f .env ] && source .env; set +a
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
